# RenReader / 幕匣 App 重链接材料

此 kit 提供实际 Build 9 的 185 个 App 对象、Swift module、7z 静态库与 symbol mask；不含 Apple SDK、Apple 工具、签名或发布凭据。对象来自1.0.1 (9) 的正式设备准备 Archive。本版采用原有的精确原生库提供文件，并用新归档 App 对象重放链接。

使用 Python 3.9 或更新版本，并自行合法安装匹配 Xcode 27.1／iPhoneOS 27.1 SDK。提供材料中单独的 20 个公共 framework provider，包含重新构建的 8.5.4，不需要也不应提供 Live2D Core：

```sh
python3 replay_portable.py --kit /relocated/Kit \
  --manifest-sha SHA256_OF_PORTABLE_MANIFEST \
  --artifact-root /relocated/Providers \
  --sdk /path/to/iPhoneOS27.1.sdk \
  --clang /path/to/XcodeDefault.xctoolchain/usr/bin/clang \
  --output /fresh/path/to/UnsignedReplay
```

默认模式核验实际输入哈希，按原顺序链接／strip，并把 section、load commands、exports 和部署信息与原 App 基线比较。输出未签名，不直接安装、不上传；`receipt.json` 保留实际命令、输入、比较及输出哈希。所有原材料保持不动，输出目录必须全新。

修改 LGPL 等组件后，先按 Native 源码／构建材料重新生成相应库／framework，再在自己的 kit 副本中更新 `portable-manifest.json` 的对应 `publicFrameworks` 或 `packageFiles` SHA-256／size，重新计算清单 SHA，使用 `--modified-components` 重链接。哈希是完整性记录，不禁止依许可修改。此模式如实保留 `comparisonPassed=false`，但在真实链接成功、CPU／部署条件保持且无 Core 载入时可记录 `relinkSucceeded=true`；不能把修改模式作为原版字节等价证明。工具及平台安装条件不代替各组件许可，安装签名需使用自己的 Apple 凭据。

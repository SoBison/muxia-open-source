# 幕匣 / Muxia — source and relink materials

Muxia 1.0.1 (9) corresponding materials.

- `Sources/README.md` explains how to restore the corresponding source and build controls. The source inventory includes the updated runtime adapters and the archive assembly-time reader support script.
- `ReadingRuntime/` also provides the updated runtime files at their exact bundle-relative paths.
- `NativeRelink/README.md` documents the unchanged native components and their original verification. All 20 native device framework providers were matched by hash against the current app archive inputs.
- `AppRelink/Kit/README.md` explains how to replay linking for this version or relink against a modified library. The fresh application inputs were tested in a separate folder against the new Archive executable.
- `Licenses/` and `APPLICATION-OBJECTS-PERMISSION.txt` contain the license and relinking terms.
- `delivery-manifest.json` contains the checksum and byte count of each included file.

"""Presentation support for the bundled Ren'Py 8.5.3 and 8.5.4 text engine."""

from functools import lru_cache
from itertools import groupby
import os
import re


_FONT = "rr-host-cjk-7e42/notosanscjksc-regular.otf"
_HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U000323af]")
_BUNDLE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
_FONT_PATH = os.path.join(_BUNDLE, "TranslationFonts", "NotoSansCJKsc-Regular.otf")
_font_probe = None
_quick_menu_hook = None
_quick_menu_hidden = False


def _open_bundled_font(name):
    if name in (_FONT, "fonts/" + _FONT):
        return open(_FONT_PATH, "rb")
    return None


def install(renpy):
    global _font_probe
    if not os.path.isfile(_FONT_PATH):
        return
    # Ren'Py restores its loader callback list when opening another title.
    callbacks = renpy.loader.file_open_callbacks
    if _open_bundled_font not in callbacks:
        callbacks.insert(0, _open_bundled_font)
    if _font_probe is not None:
        return

    fonts = renpy.text.font
    text_segment = renpy.text.text.TextSegment
    original = text_segment.subsegment

    @lru_cache(maxsize=2048)
    def missing_glyph(name, bold, italic, replacement, char):
        # Only HarfBuzz exposes the shaped glyph ID (zero is .notdef).
        face = fonts.get_font(name, 16, bold, italic, 0, True, False, True, 1.0,
                              "harfbuzz", None, None, None)
        return isinstance(face, fonts.hbfont.HBFont) and all(g.glyph == 0 for g in face.glyphs(char, 0))

    def subsegment(segment, text):
        for author_segment, value in original(segment, text):
            name = author_segment.font
            if (author_segment.ignore or author_segment.shaper != "harfbuzz"
                    or not isinstance(name, str) or name == _FONT or not _HAN.search(value)):
                yield author_segment, value
                continue

            base_font = (name, author_segment.bold, author_segment.italic)
            replacement = renpy.config.font_replacement_map.get(base_font, base_font)

            def needs_fallback(char):
                return _HAN.fullmatch(char) is not None and missing_glyph(*base_font, replacement, char)

            fallback_segment = None
            for use_fallback, chars in groupby(value, needs_fallback):
                if use_fallback and fallback_segment is None:
                    fallback_segment = text_segment(author_segment)
                    fallback_segment.font = _FONT
                    fallback_segment.instance = None
                    fallback_segment.axis = None
                yield fallback_segment if use_fallback else author_segment, "".join(chars)

    text_segment.subsegment = subsegment
    _font_probe = missing_glyph


def supports_quick_menu(renpy):
    return "quick_menu" in renpy.config.overlay_screens and renpy.exports.has_screen("quick_menu")


def set_quick_menu(renpy, visible):
    global _quick_menu_hidden, _quick_menu_hook
    if type(visible) is not bool or not supports_quick_menu(renpy):
        raise ValueError("The title's quick menu is unavailable")
    screens = renpy.display.screen
    if screens.show_overlay_screens is not _quick_menu_hook:
        original = screens.show_overlay_screens

        def show_overlays(suppress_overlay):
            original(suppress_overlay)
            # Rollback can restore an earlier screen list. Apply the reader's
            # choice after Ren'Py has resolved the authored overlay screens.
            if _quick_menu_hidden and renpy.exports.get_screen("quick_menu") is not None:
                renpy.exports.hide_screen("quick_menu", immediately=True)

        screens.show_overlay_screens = _quick_menu_hook = show_overlays
    _quick_menu_hidden = not visible
    if _quick_menu_hidden:
        renpy.exports.hide_screen("quick_menu", immediately=True)
    renpy.exports.restart_interaction()


def reset():
    global _quick_menu_hidden
    _quick_menu_hidden = False
    if _font_probe is not None:
        _font_probe.cache_clear()

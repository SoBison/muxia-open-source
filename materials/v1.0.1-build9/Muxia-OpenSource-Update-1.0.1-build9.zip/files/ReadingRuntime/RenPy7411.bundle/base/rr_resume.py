"""Restore the saved statement when continuing a reader-managed checkpoint."""

_GREEDY_ROLLBACK = "_greedy_rollback"
_MISSING = object()
_original_load = None
_startup_load = None


def uninstall(renpy):
    global _original_load, _startup_load
    if _startup_load is not None and renpy.exports.load is _startup_load:
        renpy.exports.load = _original_load
    _original_load = None
    _startup_load = None


def install(renpy, slot):
    global _original_load, _startup_load
    uninstall(renpy)
    # Ren'Py script's `renpy` namespace is bound to renpy.exports.
    original = renpy.exports.load
    deferred_load = getattr(getattr(renpy, "rollback", None), "UnfreezeException", ())

    def load_checkpoint(filename):
        uninstall(renpy)
        if filename != slot:
            return original(filename)

        session = renpy.session
        previous = session.get(_GREEDY_ROLLBACK, _MISSING)
        session[_GREEDY_ROLLBACK] = False
        deferred = False
        try:
            return original(filename)
        except deferred_load:
            # Newer engines consume the override when the execution loop
            # handles this control exception, after renpy.load has unwound.
            deferred = True
            raise
        finally:
            # A declined or failed load must not affect a later manual load.
            if not deferred and session.get(_GREEDY_ROLLBACK) is False:
                if previous is _MISSING:
                    session.pop(_GREEDY_ROLLBACK)
                else:
                    session[_GREEDY_ROLLBACK] = previous

    _original_load = original
    _startup_load = load_checkpoint
    renpy.exports.load = load_checkpoint

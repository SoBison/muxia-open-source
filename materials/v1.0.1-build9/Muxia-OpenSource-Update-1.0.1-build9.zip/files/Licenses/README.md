# 幕匣 / RenReader 对应源码与重链接材料（未完成草案）

本目录保留 Build 9 所用组件的原始许可、版权和历史索引。当前版本的源码和 App 重链接文件由 delivery-manifest.json 与本版 AppRelink 复验结果标识。

`shipped-notices/` 保留当前 staging 中的原始许可、版权、修改声明及其打包相对路径。逐叶来源与 SHA-256 见 `indices/notice-copy-inventory.json`；该索引的 ObjectsFirst 标签只是当前材料快照，最终 ZIP 的根 `delivery-manifest.json` 必须重新覆盖实际交付叶。完整依赖源包、许可原文、vendor 修改和构建配置由相邻 SourceInputs 收集，最终装配时加入同一材料 ZIP。

Ren’Py 主体采用 MIT，具体文件和依赖可能采用其他许可。当前 Ren’Py 原始声明列有 FFmpeg / 旧 libav、FriBidi、较旧 chardet 和 pygame_sdl2 的 LGPL 部分；SDL2 使用自身 zlib 文本。不能把 libavif 与 FFmpeg 的 libavcodec/libavformat 等混为同一许可。pyobjus 的开源许可不需要另购商业授权，但仍需精确源码、版权和修改来源绑定。

对实际采用 LGPL 的组件，交付需按各组件实际许可版本保留完整许可与版权；提供对应源码、vendor／本地修改和生成文件所需输入、实际配置／脚本；对静态链接成分提供可用于修改该库后重新链接的适用对象、库与操作说明。最终 App 对象必须来自新的 Build 9 Archive；旧版本 187 个对象及旧路径重放仅为历史工程证明。代码签名、平台安装限制和许可适用条件需另行如实说明，不能用本机重链接演练代替所有发行条件。

最终使用入口拟为：设置 → 开源与第三方许可 → 导出开源材料包。App 仅在材料 ZIP 已由随包清单登记、大小和 SHA-256 验证通过时提供导出；未完成的包必须标明范围。外层 SHA 绑定整个 ZIP，内部根清单逐项绑定每个材料文件。材料包不是 App 二进制，也不包含发布凭据或用户数据。

这些材料只涉及实际分发的软件、字体与修改。用户导入作品不在本包内；不授予作品、商标或第三方媒体的使用权，也不代表 Apple 审核批准。

Chardet 的版本范围必须区分：实际 854 字节中的版本常量为 7.6.0，且写明 0BSD rewrite；较旧 runtime 分别保留 3.0.4 / 5.1.0 / 5.2.0 常量。对应四个官方 tag 源归档和原许可已经收集；原始 bytecode 常量只用来选择候选源，不独立证明所有 bytecode 与上游源码一致。见 indices 中的版本证据和官方源归档索引。

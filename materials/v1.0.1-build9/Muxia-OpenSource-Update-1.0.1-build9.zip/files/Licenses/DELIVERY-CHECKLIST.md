# 最终装配门槛

当前全部完成标记均为 false。以下由真实输入／输出及最终逐叶清单闭环后才能更新；文件存在不推定完成。

- 各个实际 RRRuntime、RRPlatform、RRGalleryAudio、MetalANGLE 和 7z 原生生产者：精确源版本／归档 SHA、版权和完整许可、全部 vendor／本地补丁、生成配置、编译与链接命令、依赖和可复现操作入口。
- 17 份实际 Ren’Py/Python 资源：对应官方源、当前宿主 glue 与修改、生成／裁剪／编译说明；多版本不能仅用一个较新源包替代。
- LGPL 的实际静态链接库：精确 FFmpeg/libav、FriBidi、pygame_sdl2 等适用源码／配置和重链接输入；以实际每版本链接图为准。Python 层各 chardet 版本同时保留各自相应源和许可；854 的 7.6.0 重写分支不因旧通用列表而误称 LGPL。没有被证实纳入实际包的库不因上游通用列表而直接声称已分发。
- 字体：TranslationFonts 各自 OFL／来源及 manifest；信任提示子集保留与实际 NotoSansSC Thin 2.004/Adobe 保留名相符的独立 OFL，不能用其他 Noto 字体的许可替换。
- 当前 Build 9 新 App Archive 的全部适用重链接对象／原命令／实际库和独立重放结果；不能把旧 App 的对象当作新对象。
- 将 SourceInputs、精确许可、补丁、脚本、当前 App 重链接输入与使用说明装配为最终 ZIP，排除历史退役 Core／许可、Validation、发布凭据及用户数据。
- root 核验内部 delivery-manifest.json 精确覆盖全部非目录／非清单叶，完成声明有事实依据；生成外层清单记录 ZIP 大小、SHA-256 和内部清单 SHA-256。
- 最终 App 包实际核验无两套 Live2D Core／Native Framework、无当前 Live2D 许可条目，材料 ZIP 与清单逐字节匹配，导出操作实际可用。新包未取得此证明前不称移除完成或可提交审核。

最终装配还需按已核验事实刷新此处“未完成草案”说明，不将历史 pending 文案与未经核实的 complete=true 混装。

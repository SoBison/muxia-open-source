#!/usr/bin/env python3
"""Verify a Muxia base ZIP and update ZIP, then create the exact combined materials ZIP."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import stat
import zipfile


DELIVERY = 'delivery-manifest.json'
DELTA = 'delta-manifest.json'
UPDATE_METADATA = {DELIVERY, DELTA, 'README.md', 'restore_materials.py'}
MAX_MANIFEST = 1024**2
MAX_PACKAGE = 8 * 1024**3
CHUNK = 1024**2


def digest(stream, copy_to=None, limit=MAX_PACKAGE):
    sha = hashlib.sha256()
    count = 0
    while chunk := stream.read(CHUNK):
        count += len(chunk)
        if count > limit:
            raise ValueError('File exceeds the permitted byte count')
        sha.update(chunk)
        if copy_to is not None:
            copy_to.write(chunk)
    return {'byteCount': count, 'sha256': sha.hexdigest()}


def file_digest(path):
    with path.open('rb') as source:
        return digest(source)


def unique_fields(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('Duplicate field in a manifest: ' + key)
        result[key] = value
    return result


def safe_name(name):
    return (isinstance(name, str) and '\\' not in name and ':' not in name
            and all(ord(char) >= 32 for char in name)
            and all(part not in ('', '.', '..') for part in name.split('/')))


def entries(archive):
    files = {}
    for entry in archive.infolist():
        name = entry.filename
        if not safe_name(name) or name != entry.orig_filename or name in files or entry.is_dir():
            raise ValueError('Invalid or duplicate ZIP entry: ' + name)
        if entry.flag_bits & 1 or stat.S_IFMT(entry.external_attr >> 16) not in (0, stat.S_IFREG):
            raise ValueError('Expected a regular, unencrypted ZIP entry: ' + name)
        files[name] = entry
    return files


def read_manifest(archive, name):
    size = archive.getinfo(name).file_size
    if not 0 < size <= MAX_MANIFEST:
        raise ValueError('Invalid manifest size: ' + name)
    data = archive.read(name)
    return data, json.loads(data, object_pairs_hook=unique_fields)


def delivery_inventory(archive):
    data, manifest = read_manifest(archive, DELIVERY)
    if (manifest.get('schemaVersion') != 1 or manifest.get('sourceDeliveryComplete') is not True
            or manifest.get('relinkDeliveryComplete') is not True):
        raise ValueError('Expected complete corresponding source and relinking materials')
    rows = {}
    for row in manifest['files']:
        name = row['path']
        if (set(row) != {'path', 'byteCount', 'sha256'} or not safe_name(name) or name == DELIVERY or name in rows
                or type(row['byteCount']) is not int or not 0 <= row['byteCount'] <= MAX_PACKAGE
                or not re.fullmatch('[0-9a-f]{64}', row['sha256'])):
            raise ValueError('Invalid or duplicate delivery inventory entry: ' + str(name))
        rows[name] = {k: row[k] for k in ('byteCount', 'sha256')}
    if not rows or sum(row['byteCount'] for row in rows.values()) > MAX_PACKAGE:
        raise ValueError('Delivery inventory is empty or exceeds the package size limit')
    return data, rows


def mode(info):
    return 0o755 if (info.external_attr >> 16) & 0o111 else 0o644


def zip_entry(name, size, permissions):
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.create_version = info.extract_version = 20
    info.external_attr = (stat.S_IFREG | permissions) << 16
    info.file_size = size
    return info


def write_full(target, manifest, rows, sources):
    # The restored package fits ordinary ZIP. Fixed headers and stored contents
    # keep the result identical across Python and zlib versions.
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_STORED, allowZip64=False) as result:
        for name in sorted(rows):
            source, key = sources[name]
            expected = rows[name]
            item = source.getinfo(key)
            if item.file_size != expected['byteCount']:
                raise ValueError('Wrong file size: ' + name)
            info = zip_entry(name, item.file_size, mode(item))
            with source.open(item) as incoming, result.open(info, 'w') as outgoing:
                if digest(incoming, outgoing, limit=item.file_size) != expected:
                    raise ValueError('Wrong file checksum: ' + name)
        result.writestr(zip_entry(DELIVERY, len(manifest), 0o644), manifest)


def check_base(path, archive, pin):
    if {key: pin[key] for key in ('byteCount', 'sha256')} != file_digest(path):
        raise ValueError('The base ZIP does not match the published checksum or size')
    manifest, rows = delivery_inventory(archive)
    if hashlib.sha256(manifest).hexdigest() != pin['deliveryManifestSHA256']:
        raise ValueError('The base ZIP contains a different delivery manifest')
    if set(entries(archive)) != set(rows) | {DELIVERY}:
        raise ValueError('The base ZIP does not match its delivery inventory')
    return rows


def reconstruct(base_path, delta_path, output):
    with zipfile.ZipFile(base_path) as base, zipfile.ZipFile(delta_path) as delta:
        _, recipe = read_manifest(delta, DELTA)
        if recipe.get('schemaVersion') != 1:
            raise ValueError('Unsupported update manifest version')
        base_rows = check_base(base_path, base, recipe['base'])
        manifest, rows = delivery_inventory(delta)
        changed = recipe['changedPaths']
        expected = recipe['reconstructed']
        manifest_sha = hashlib.sha256(manifest).hexdigest()
        if expected['deliveryManifestSHA256'] != manifest_sha:
            raise ValueError('The update does not contain the expected complete delivery manifest')
        if (changed != sorted(set(changed)) or not set(changed) <= set(rows)
                or set(entries(delta)) != UPDATE_METADATA | {'files/' + name for name in changed}):
            raise ValueError('The update ZIP does not match its update inventory')
        reused = rows.keys() - set(changed)
        if any(rows[name] != base_rows.get(name) for name in reused):
            raise ValueError('A required changed file is missing from the update ZIP')
        sources = {name: (base, name) for name in reused}
        sources.update({name: (delta, 'files/' + name) for name in changed})
        # Exclusive open protects an existing output. Remove only this run's partial file.
        with output.open('xb') as out:
            try:
                write_full(out, manifest, rows, sources)
                out.flush()
                receipt = dict(file_digest(output), deliveryManifestSHA256=manifest_sha)
                if receipt != expected:
                    raise ValueError('The reconstructed ZIP does not match the expected checksum or size')
            except BaseException:
                out.close()
                output.unlink()
                raise
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base_zip', type=Path)
    parser.add_argument('update_zip', type=Path)
    parser.add_argument('output_zip', type=Path)
    args = parser.parse_args()
    print(json.dumps(reconstruct(args.base_zip, args.update_zip, args.output_zip), indent=2))


if __name__ == '__main__':
    main()
